# Rub al-Khali KG 3.0.1

Released 2026-10-04. Bulk reconstruction and export ran on ws, using the pinned
Virtuoso engine recorded by stage_database.py. Unpack the separately distributed
modules archive into inputs/scientific. Create venv with Python 3, install
code/backend-requirements.lock, and install the Raptor rapper command.
Stage a NEW empty database, run
load_asserted.py, configure_dataset.sql, then rebuild_export.py and validate_export.py.
run_pipeline.py ends by preparing a private VM snapshot for our deployment;
omit prepare_vm_snapshot.py for an independent RDF-only reconstruction.
Scripts record the actual isolated build directory; adjust this directory for
an independent reconstruction. Never load into a populated or production database.
The 70-coordinate POINT whitespace adapter changes only loader copies.

Fifteen scientific/reference module files are byte-identical to 3.0.0. The root
TBox adds 342 reviewed English definitions, licensing and release metadata;
only reference vocabularies remain owl:imports. Observation modules are DCAT
hasPart links. Existing term axioms are preserved. build_ontology.py records the
old TBox hash and validates all term axioms and four RDF serializations.
Definitions were drafted by actual Claude Code --model sonnet, then reviewed
and edited by Codex; definition-provenance.json preserves drafts and dispositions.

Only asserted RDF is released. No inference or scientific observation regeneration
is claimed. This kit contains load/export code and release evidence, not all raw
scientific producer inputs. Scientific producer source:
https://github.com/bio-ontology-research-group/empty-quarter-data-paper .
Project RDF and terms: CC BY 4.0. Software: MIT. Imported terms retain their own
licences, listed in THIRD_PARTY_ATTRIBUTIONS.json. Credentials are not included.
