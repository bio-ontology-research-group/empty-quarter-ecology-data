import subprocess,time,json,hashlib
from pathlib import Path
R=Path('/mnt/data1/empty-quarter-releases/kg-3.0.1-20261004');out=R/'evidence/parsed-export-parts.json';done={};suffix=b' <https://rubalkhali.science/graph/asserted/3.0.1> .\n'
while True:
 complete=(R/'evidence/asserted_export.json').exists();parts=sorted((R/'exports').glob('asserted-*.nq'));ready=parts if complete else parts[:-1]
 for p in ready:
  if p.name in done:continue
  subprocess.run(['docker','exec','-u','0','eq_kg_3_0_1','chmod','0644','/release-exports/'+p.name],check=True)
  with (R/'evidence'/('parse-'+p.stem+'.log')).open('w') as log:
   process=subprocess.Popen(['rapper','-i','nquads','-o','nquads',str(p)],stdout=subprocess.PIPE,stderr=log)
   n=0
   for line in process.stdout:
    assert line.split(b' ',2)[2].endswith(suffix),'Unexpected graph context';n+=1
   assert process.wait()==0
  done[p.name]=dict(quads=n,passed=True);out.write_text(json.dumps(done,indent=2)+'\n');print(p.name,n,flush=True)
 if complete and len(done)==len(parts):break
 time.sleep(3)
expected=json.loads((R/'evidence/asserted_load/report.json').read_text())['triples']
assert sum(x['quads'] for x in done.values())==expected
(R/'evidence/parsed-export.json').write_text(json.dumps(dict(passed=True,quads=expected,parts=len(done),parser='Raptor rapper; all graph contexts verified'),indent=2)+'\n')
