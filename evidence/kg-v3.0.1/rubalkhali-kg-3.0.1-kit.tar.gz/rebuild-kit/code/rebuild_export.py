"""Finish the KG 3.0.1 ontology and licensing rebuild; every artifact has a new rebuild name."""
import sys,time,json,gzip,hashlib,shutil,subprocess
from pathlib import Path
ROOT=Path('/mnt/data1/empty-quarter-releases/kg-3.0.1-20261004')
sys.path.insert(0,str(ROOT/'code'))
from kg_admin import execute
from load_asserted import count
C='eq_kg_3_0_1';G='https://rubalkhali.science/graph/asserted/3.0.1'; E='http://127.0.0.1:18896/sparql'
def sql(s,name):
 out,failed=execute(C,s,timeout=14400);(ROOT/'evidence'/name).write_text(out)
 if failed: raise RuntimeError(name)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def main():
 report=ROOT/'evidence/asserted_load/report.json'
 for _ in range(720):
  if report.exists():break
  time.sleep(10)
 else:raise TimeoutError('asserted load')
 expected=json.loads(report.read_text())['triples']; assert 45707600 < expected < 45707700
 sql((ROOT/'code/configure_dataset.sql').read_text(),'configure_dataset.log')
 sql((ROOT/'code/export_graph.sql').read_text(),'install_exporter.log')
 shutil.copy2(ROOT/'code/export_fixture.ttl', ROOT/'inputs/export_fixture.ttl')
 sql((ROOT/'code/export_fixture.sql').read_text(),'export_fixture.log')
 subprocess.run(['docker','exec','-u','0',C,'chmod','0644','/release-exports/export-fixture-000001.nq'],check=True)
 subprocess.run([str(ROOT/'venv/bin/python'),str(ROOT/'code/verify_export_fixture.py'),'--export',str(ROOT/'exports/export-fixture-000001.nq'),'--output',str(ROOT/'evidence/export_fixture.json')],check=True)
 sql("SPARQL CLEAR GRAPH <urn:eq:release-test:export>;\nCHECKPOINT;",'clear_fixture.log')
 sql("DB.DBA.EQ_EXPORT_GRAPH ('"+G+"', '/release-exports/asserted-', 250000000);",'export_asserted.log')
 parts=sorted((ROOT/'exports').glob('asserted-*.nq'));assert parts
 subprocess.run(['docker','exec','-u','0',C,'chmod','0644',*('/release-exports/'+p.name for p in parts)],check=True)
 pub=ROOT/'publication/kg/3.0.1';pub.mkdir(parents=True,exist_ok=True)
 name='rubalkhali-kg-3.0.1-asserted.nq.gz';target=pub/name
 raw=hashlib.sha256();lines=0
 with target.open('xb') as dest,gzip.GzipFile(filename='',mode='wb',fileobj=dest,compresslevel=1,mtime=0) as z:
  for p in parts:
   with p.open('rb') as f:
    for b in iter(lambda:f.read(8*1024*1024),b''):raw.update(b);lines+=b.count(b'\n');z.write(b)
 assert lines==expected==count(E)
 entry=dict(name=name,url='https://bio2vec.net/data/empty-quarter/kg/3.0.1/'+name,bytes=target.stat().st_size,sha256=sha(target),uncompressed_sha256=raw.hexdigest(),triples=lines,graph=G,kind='asserted',media_type='application/gzip',description='Rebuilt deduplicated asserted union of the sixteen checksum-listed KG 3.0.1 inputs; no inferred triples.')
 (ROOT/'evidence/asserted_export.json').write_text(json.dumps(dict(passed=True,files=[entry]),indent=2)+'\n')
 print(json.dumps(entry),flush=True)
main()
