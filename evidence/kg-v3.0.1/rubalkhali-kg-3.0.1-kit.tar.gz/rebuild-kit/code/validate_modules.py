import tarfile,json,hashlib
from pathlib import Path
R=Path('/mnt/data1/empty-quarter-releases/kg-3.0.1-20261004');m=json.loads((R/'inputs/scientific/manifest.json').read_text());expected={r['file']:r for r in m['records']};seen={}
with tarfile.open(R/'publication/kg/3.0.1/rubalkhali-kg-3.0.1-modules.tar.gz','r|gz') as t:
 for member in t:
  if member.isdir():continue
  if member.name in ['LICENSE-DATA.md','LICENSE-SOFTWARE','THIRD_PARTY_ATTRIBUTIONS.json']:continue
  assert member.isfile() and member.name.startswith('scientific/');name=member.name.split('/')[1];assert name in expected or name=='manifest.json'
  f=t.extractfile(member);h=hashlib.sha256()
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
  if name in expected:assert member.size==expected[name]['bytes'] and h.hexdigest()==expected[name]['sha256'];seen[name]=h.hexdigest()
assert set(seen)==set(expected)
(R/'evidence/module-archive-validation.json').write_text(json.dumps(dict(passed=True,modules=16,hashes=seen),indent=2)+'\n');print('PASS all 16 archived input files match checksum-listed 3.0.1 input hashes')
