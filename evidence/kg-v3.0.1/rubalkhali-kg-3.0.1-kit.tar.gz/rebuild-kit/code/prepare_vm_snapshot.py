import subprocess,time,json,hashlib,sys
from pathlib import Path
R=Path('/mnt/data1/empty-quarter-releases/kg-3.0.1-20261004');image='openlink/virtuoso-opensource-7@sha256:0dbe1ab4fa0cb7bbafc1f6c0c2b0a5d6f22d918dbd17672f2ddb24580aa6756a'
for _ in range(720):
 if (R/'evidence/asserted_export.json').exists() and (R/'evidence/parsed-export.json').exists():break
 time.sleep(5)
else:raise TimeoutError('export validation not completed')
subprocess.run([sys.executable,str(R/'code/kg301/package_release.py')],check=True)
subprocess.run(['docker','stop','--time','180','eq_kg_3_0_1'],check=True)
# No database writes occur while the cold snapshot is copied.
subprocess.run(['docker','run','--rm','--network','none','--user','0','--entrypoint','sh','-v',str(R/'database')+':/database:ro','-v',str(R/'exports')+':/out',image,'-c','tar -C /database -cf - . | gzip -1 > /out/database-cold.tgz'],check=True)
p=R/'exports/database-cold.tgz';h=hashlib.sha256()
with p.open('rb') as f:
 for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
(R/'evidence/database-snapshot.json').write_text(json.dumps(dict(sha256=h.hexdigest(),bytes=p.stat().st_size,engine=image,source='ws cold snapshot after all release gates',passed=True),indent=2)+'\n')
# Random build-only DBA credential moves directly ws -> VM, never to this
# client or to the public artifact directory. Remote-connect credentials stay put.
for src,dst in [(p,'/tmp/eq-kg301-database.tgz'),(R/'database.private.env','/tmp/eq-kg301-private.env'),(R/'evidence/database-snapshot.json','/tmp/eq-kg301-snapshot.json')]:
 subprocess.run(['sshpass','-f','/mnt/data1/agents/secrets/remote-connect/password.md','scp',str(src),'a-hohndor@10.254.146.67:'+dst],check=True)
print('Validated cold snapshot transferred to VM',flush=True)
