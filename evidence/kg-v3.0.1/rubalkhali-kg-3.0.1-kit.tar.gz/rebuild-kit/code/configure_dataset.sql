-- Dataset selection is enforced by the read-only gateway. Do not override explicit FROM.
DELETE FROM DB.DBA.SYS_SPARQL_HOST WHERE SH_HOST='*';
CHECKPOINT;
