#!/usr/bin/env python3
"""Assemble 3.0.1 release files after RDF and archive validation, on ws only."""
import json,hashlib,tarfile,shutil
from pathlib import Path
R=Path('/mnt/data1/empty-quarter-releases/kg-3.0.1-20261004');P=R/'publication/kg/3.0.1';BASE='https://bio2vec.net/data/empty-quarter/kg/3.0.1/'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def main():
 for n in ['asserted_export.json','parsed-export.json','module-archive-validation.json']:
  assert json.loads((R/'evidence'/n).read_text())['passed'],n
 for n in ['LICENSE-DATA.md','LICENSE-SOFTWARE','THIRD_PARTY_ATTRIBUTIONS.json']:shutil.copy2(R/'code/kg301'/n,P/n)
 shutil.copy2(R/'code/kg301/definitions.json',P/'definition-provenance.json')
 for src,dst in [('inputs/scientific/manifest.json','input-modules-manifest.json'),('evidence/asserted_load/report.json','asserted-loader-report.json'),('evidence/export_fixture.json','export-fixture-validation.json')]:shutil.copy2(R/src,P/dst)
 triples=json.loads((R/'evidence/asserted_load/report.json').read_text())['triples']
 files=json.loads((R/'evidence/asserted_export.json').read_text())['files']
 kit=R/'rebuild-kit';kit.mkdir(exist_ok=False)
 (kit/'code').mkdir()
 for n in ['stage_database.py','load_asserted.py','kg_admin.py','prepare_wkt_import.py','configure_dataset.sql','export_graph.sql','export_fixture.ttl','export_fixture.sql','verify_export_fixture.py','rebuild_export.py','validate_export.py','archive301.py','validate_modules.py','run_pipeline.py','prepare_vm_snapshot.py','backend-requirements.lock']:
  shutil.copy2(R/'code'/n,kit/'code'/n)
 shutil.copytree(R/'code/kg301',kit/'code/kg301',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
 for n in ['LICENSE-DATA.md','LICENSE-SOFTWARE','THIRD_PARTY_ATTRIBUTIONS.json','input-modules-manifest.json','asserted-loader-report.json','export-fixture-validation.json']:shutil.copy2(P/n,kit/n)
 for n in ['parsed-export.json','module-archive-validation.json']:shutil.copy2(R/'evidence'/n,kit/n)
 (kit/'README.md').write_text('''# Rub al-Khali KG 3.0.1

Released 2026-10-04. Bulk reconstruction and export ran on ws, using the pinned
Virtuoso engine recorded by stage_database.py. Unpack the separately distributed
modules archive into inputs/scientific. Create venv with Python 3, install
code/backend-requirements.lock, and install the Raptor rapper command.
Stage a NEW empty database, run
load_asserted.py, configure_dataset.sql, then rebuild_export.py and validate_export.py.
run_pipeline.py ends by preparing a private VM snapshot for our deployment;
omit prepare_vm_snapshot.py for an independent RDF-only reconstruction.
Scripts record the actual isolated build directory; adjust this directory for
an independent reconstruction. Never load into a populated or production database.
The 70-coordinate POINT whitespace adapter changes only loader copies.

Fifteen scientific/reference module files are byte-identical to 3.0.0. The root
TBox adds 342 reviewed English definitions, licensing and release metadata;
only reference vocabularies remain owl:imports. Observation modules are DCAT
hasPart links. Existing term axioms are preserved. build_ontology.py records the
old TBox hash and validates all term axioms and four RDF serializations.
Definitions were drafted by actual Claude Code --model sonnet, then reviewed
and edited by Codex; definition-provenance.json preserves drafts and dispositions.

Only asserted RDF is released. No inference or scientific observation regeneration
is claimed. This kit contains load/export code and release evidence, not all raw
scientific producer inputs. Scientific producer source:
https://github.com/bio-ontology-research-group/empty-quarter-data-paper .
Project RDF and terms: CC BY 4.0. Software: MIT. Imported terms retain their own
licences, listed in THIRD_PARTY_ATTRIBUTIONS.json. Credentials are not included.
''')
 # Prevent accidentally including this isolated build's random DBA password.
 secret=(R/'database.private.env').read_text().split('DBA_PASSWORD=',1)[1].splitlines()[0].encode()
 assert all(secret not in f.read_bytes() for f in kit.rglob('*') if f.is_file())
 name='rubalkhali-kg-3.0.1-kit.tar.gz'
 with tarfile.open(P/name,'w:gz',compresslevel=1) as t:t.add(kit,arcname='rebuild-kit')
 for n,k,desc,mime in [(name,'source','Rebuild code, reviewed definition provenance and validation evidence.','application/gzip'),('rubalkhali-kg-3.0.1-modules.tar.gz','modules','Sixteen RDF modules, checksum manifest and scoped licence notices.','application/gzip'),('ontology/rubalkhali.owl','ontology','OWL TBox with 342 English term definitions; reference ontology imports are separately licensed.','application/rdf+xml')]:
  f=P/n;files.append(dict(name=n.split('/')[-1],url=BASE+n,bytes=f.stat().st_size,sha256=sha(f),kind=k,media_type=mime,description=desc))
 m=dict(version='3.0.1',release_mode='asserted-only',released_at='2026-10-04',version_iri='https://rubalkhali.science/kb/v3.0.1/',license='https://creativecommons.org/licenses/by/4.0/',license_scope='Project-authored RDF, ontology terms and metadata; imported content retains source licences.',third_party_licenses=BASE+'THIRD_PARTY_ATTRIBUTIONS.json',files=files,graphs={'asserted':'https://rubalkhali.science/graph/asserted/3.0.1'},counts={'asserted':triples},default_graph='https://rubalkhali.science/graph/asserted/3.0.1',available_modes=['asserted'],query_time_inference=False,input_manifest_url=BASE+'input-modules-manifest.json',input_manifest_sha256=sha(P/'input-modules-manifest.json'),source_repository='https://github.com/bio-ontology-research-group/empty-quarter-data-paper',previous_release='https://bio2vec.net/data/empty-quarter/kg/3.0.0/manifest.json',changes=['CC BY 4.0 for project-authored RDF, terms and dataset metadata; imported licences preserved','342 Sonnet-drafted and Codex-reviewed definitions','Resolvable ontology documents, imports and dataset discovery metadata'],definition_provenance=BASE+'definition-provenance.json')
 (P/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
 from build_discovery import build
 build(P/'manifest.json',P)
 sd='''@prefix sd: <http://www.w3.org/ns/sparql-service-description#> .
@prefix void: <http://rdfs.org/ns/void#> .
@prefix dct: <http://purl.org/dc/terms/> .
<https://rubalkhali.science/sparql> a sd:Service;
 sd:endpoint <https://rubalkhali.science/sparql>;
 sd:supportedLanguage sd:SPARQL11Query;
 sd:defaultDataset [ a sd:Dataset; sd:defaultGraph [ a sd:Graph; void:triples TRIPLES; dct:license <https://creativecommons.org/licenses/by/4.0/> ];
 sd:namedGraph [ a sd:NamedGraph; sd:name <https://rubalkhali.science/graph/asserted/3.0.1>; sd:graph [ a sd:Graph; void:triples TRIPLES ] ] ] .
'''.replace('TRIPLES',str(triples));(P/'service-description.ttl').write_text(sd)
 (P/'SHA256SUMS').write_text(''.join(sha(f)+'  '+str(f.relative_to(P))+'\n' for f in sorted(P.rglob('*')) if f.is_file() and f.name!='SHA256SUMS'))
 print(json.dumps(m,indent=2))
if __name__=='__main__':main()
