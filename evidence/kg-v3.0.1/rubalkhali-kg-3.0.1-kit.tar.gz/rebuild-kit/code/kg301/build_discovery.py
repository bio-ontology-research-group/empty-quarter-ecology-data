#!/usr/bin/env python3
"""Generate static schema.org, DCAT and VoID descriptions from the release manifest."""
import argparse,json
from pathlib import Path
from rdflib import Graph,Namespace,URIRef,Literal,BNode
from rdflib.namespace import RDF,RDFS,DCTERMS,XSD
BASE='https://bio2vec.net/data/empty-quarter/kg/3.0.1/'
LIC='https://creativecommons.org/licenses/by/4.0/'
DATA='https://rubalkhali.science/data'
DCAT=Namespace('http://www.w3.org/ns/dcat#');VOID=Namespace('http://rdfs.org/ns/void#');SPDX=Namespace('http://spdx.org/rdf/terms#')
def build(manifest,out):
 out.mkdir(parents=True,exist_ok=True);m=json.loads(manifest.read_text());assert m['version']=='3.0.1'
 names=['Rund Tawfiq','Marwa Abdelhakim','Sulaiman M. Alajel','Mohammed Alarawi','Hind Aldakhil','Abderahmane Derouiche','Daniela I. Drautz-Moses','Michel Dumontier','Raik Grünberg','Maxat Kulmanov','Alejandra Lopez Velazquez','Susana Martinez Arbas','Kexin Niu','Krishnakumar Sivakumar','Tiannyu Wang','Xiang Zhao','Jood Kamal Zubair','Magnus Rueping','Robert Hoehndorf']
 desc='Five-expedition desert microbiome survey of 60 core sites and 10 named locations of special interest in the Rub al-Khali, integrating 16S rRNA amplicon profiles, environmental observations, climate, archived-soil pH, XRF geochemistry and provenance. Version 3.0.1 contains asserted RDF only. Project-authored data and ontology terms are CC BY 4.0; imported vocabularies retain their source licences.'
 title="Rub al-Khali microbial survey and knowledge graph, version 3.0.1"
 people=[{'@type':'Person','name':n,**({'@id':'https://orcid.org/0000-0001-8149-5890'} if n=='Robert Hoehndorf' else {})} for n in names]
 payload={'@context':'https://schema.org/','@type':'Dataset','@id':BASE+'dataset.ttl#dataset','identifier':BASE+'dataset.ttl#dataset','name':title,'description':desc,'url':DATA,'version':'3.0.1','datePublished':'2026-10-04','dateModified':'2026-10-04','license':LIC,'isAccessibleForFree':True,'inLanguage':'en','creator':people,'publisher':{'@type':'Organization','name':'Bio-Ontology Research Group, KAUST','url':'https://borg.kaust.edu.sa/'},'keywords':['desert microbiome','16S rRNA amplicon','Rub al-Khali','Empty Quarter','XRF geochemistry','knowledge graph','OWL ontology','Saudi Arabia'],'spatialCoverage':{'@type':'Place','name':'Rub al-Khali (Empty Quarter), Saudi Arabia'},'temporalCoverage':'2022/2026','variableMeasured':['taxon read abundance','XRF analyte concentration','temperature','atmospheric pressure','relative humidity','monthly precipitation','archived-soil pH'],'subjectOf':{'@type':'SoftwareSourceCode','codeRepository':m['source_repository']},'distribution':[]}
 g=Graph();g.bind('dcat',DCAT);g.bind('void',VOID);g.bind('dct',DCTERMS);g.bind('spdx',SPDX);s=URIRef(payload['@id'])
 for t in (DCAT.Dataset,VOID.Dataset):g.add((s,RDF.type,t))
 for p,o in [(DCTERMS.title,Literal(title,lang='en')),(DCTERMS.description,Literal(desc,lang='en')),(DCTERMS.license,URIRef(LIC)),(DCTERMS.accessRights,URIRef('http://publications.europa.eu/resource/authority/access-right/PUBLIC')),(DCTERMS.issued,Literal('2026-10-04',datatype=XSD.date)),(DCTERMS.modified,Literal('2026-10-04',datatype=XSD.date)),(DCAT.version,Literal('3.0.1')),(DCAT.landingPage,URIRef(DATA)),(DCTERMS.publisher,URIRef('https://borg.kaust.edu.sa/')),(DCTERMS.isVersionOf,URIRef(DATA)),(DCTERMS.replaces,URIRef('https://bio2vec.net/data/empty-quarter/kg/3.0.0/manifest.json')),(VOID.triples,Literal(m['counts']['asserted'])),(VOID.sparqlEndpoint,URIRef('https://rubalkhali.science/sparql')),(VOID.uriSpace,Literal('https://rubalkhali.science/kb/')),(VOID.vocabulary,URIRef('https://rubalkhali.science/kb/')),(DCTERMS.provenance,URIRef(BASE+'definition-provenance.json'))]:g.add((s,p,o))
 for person in people:
  node=URIRef(person['@id']) if '@id' in person else BNode();g.add((s,DCTERMS.creator,node));g.add((node,RDFS.label,Literal(person['name'])))
 service=URIRef('https://rubalkhali.science/sparql');g.add((service,RDF.type,DCAT.DataService));g.add((service,DCAT.endpointURL,service));g.add((service,DCAT.servesDataset,s));g.add((service,DCTERMS.title,Literal('Read-only SPARQL endpoint')))
 for i,f in enumerate(m['files']):
  if f['kind']=='source':continue
  d=URIRef(BASE+'#distribution-'+str(i));url=URIRef(f['url']);g.add((s,DCAT.distribution,d));g.add((d,RDF.type,DCAT.Distribution))
  for p,o in [(DCTERMS.title,Literal(f['name'])),(DCAT.downloadURL,url),(DCAT.accessURL,url),(DCAT.byteSize,Literal(f['bytes'],datatype=XSD.decimal)),(DCAT.mediaType,URIRef('https://www.iana.org/assignments/media-types/'+f['media_type'])),(DCTERMS.license,URIRef(LIC)),(DCTERMS.rights,Literal('Project content CC BY 4.0; third-party content retains the licences in THIRD_PARTY_ATTRIBUTIONS.json.'))]:g.add((d,p,o))
  checksum=BNode();g.add((d,SPDX.checksum,checksum));g.add((checksum,RDF.type,SPDX.Checksum));g.add((checksum,SPDX.algorithm,SPDX.checksumAlgorithm_sha256));g.add((checksum,SPDX.checksumValue,Literal(f['sha256'],datatype=XSD.hexBinary)))
  if f['kind']=='asserted':g.add((s,VOID.dataDump,url))
  payload['distribution'].append({'@type':'DataDownload','name':f['name'],'description':f['description'],'contentUrl':f['url'],'encodingFormat':f['media_type'],'contentSize':str(f['bytes'])+' bytes','license':LIC})
 modules=json.loads((manifest.parent/'input-modules-manifest.json').read_text())
 for rec in modules['records']:g.add((s,DCTERMS.hasPart,URIRef(BASE+'modules/'+rec['file'])))
 (out/'dataset.json').write_text(json.dumps(payload,indent=2,ensure_ascii=False)+'\n');(out/'dataset.jsonld').write_text(json.dumps(payload,indent=2,ensure_ascii=False)+'\n')
 g.serialize(out/'dataset.ttl',format='turtle');g.serialize(out/'void.ttl',format='turtle')
 print('Generated static schema.org/DCAT/VoID metadata')
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--manifest',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();build(a.manifest,a.output)
