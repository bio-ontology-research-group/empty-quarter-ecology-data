#!/usr/bin/env python3
"""Build the 3.0.1 TBox from the frozen 3.0.0 TBox and reviewed definitions."""
import argparse, hashlib, html, json
from pathlib import Path
from rdflib import Graph, Literal, Namespace, URIRef
from rdflib.namespace import RDF, RDFS, OWL, DCTERMS, SKOS, XSD
from rdflib.compare import isomorphic
KB=Namespace('https://rubalkhali.science/kb/')
BASE='https://bio2vec.net/data/empty-quarter/kg/3.0.1/'
LICENSE=URIRef('https://creativecommons.org/licenses/by/4.0/')
IAO=URIRef('http://purl.obolibrary.org/obo/IAO_0000115')
VANN=Namespace('http://purl.org/vocab/vann/')
PAV=Namespace('http://purl.org/pav/')
def build(source, definitions, output):
    output.mkdir(parents=True,exist_ok=True)
    g=Graph().parse(source,format='xml'); old=Graph()
    for triple in g:old.add(triple)
    root=URIRef(str(KB)); rows=json.loads(definitions.read_text())['definitions']
    types=(OWL.Class,OWL.ObjectProperty,OWL.DatatypeProperty,OWL.AnnotationProperty,RDF.Property)
    terms={s for t in types for s in g.subjects(RDF.type,t) if str(s).startswith(str(KB)+'RAK_')}
    assert len(rows)==len({r['iri'] for r in rows})==len(terms)==342
    assert {URIRef(r['iri']) for r in rows}==terms
    for r in rows:
        assert len(r['definition'])>30 and r['definition'].endswith('.')
        for p in (IAO,SKOS.definition):g.add((URIRef(r['iri']),p,Literal(r['definition'],lang='en')))
    for p in (IAO,SKOS.definition):g.add((p,RDF.type,OWL.AnnotationProperty))
    # Only reference vocabularies are TBox imports. Bulk observation modules
    # belong to the separately described dataset, not the ontology import closure.
    g.remove((root,OWL.imports,None))
    for name in ('sio.owl','envo.owl','pato.owl','uo.owl'):
        g.add((root,OWL.imports,URIRef(BASE+'modules/'+name)))
    for p in (OWL.versionIRI,OWL.versionInfo,DCTERMS.modified,DCTERMS.license,DCTERMS.publisher,DCTERMS.creator,PAV.version,PAV.previousVersion):g.remove((root,p,None))
    for p,o in [(PAV.version,Literal('v3.0.1')),(PAV.previousVersion,Literal('v3.0.0')),(OWL.versionIRI,URIRef(str(KB)+'v3.0.1/')),(OWL.versionInfo,Literal('3.0.1')),
        (OWL.priorVersion,URIRef(str(KB)+'v3.0.0/')),(DCTERMS.modified,Literal('2026-10-04',datatype=XSD.date)),
        (DCTERMS.license,LICENSE),(DCTERMS.creator,URIRef('https://orcid.org/0000-0001-8149-5890')),
        (DCTERMS.publisher,URIRef('https://borg.kaust.edu.sa/')),
        (DCTERMS.source,URIRef('https://github.com/bio-ontology-research-group/empty-quarter-data-paper')),
        (DCTERMS.provenance,URIRef(BASE+'definition-provenance.json')),
        (VANN.preferredNamespacePrefix,Literal('rak')),(VANN.preferredNamespaceUri,Literal(str(KB))),
        (RDFS.isDefinedBy,URIRef(str(KB)+'v3.0.1/'))]:g.add((root,p,o))
    for s,label in [('https://orcid.org/0000-0001-8149-5890','Robert Hoehndorf'),('https://borg.kaust.edu.sa/','Bio-Ontology Research Group, KAUST')]:g.add((URIRef(s),RDFS.label,Literal(label)))
    # Check all existing term axioms, including blank-node restrictions, survive.
    for triple in old:
        if triple[0]!=root:assert triple in g, triple
    for ext,fmt in [('owl','xml'),('ttl','turtle'),('jsonld','json-ld'),('nt','nt')]:
        path=output/f'rubalkhali.{ext}';g.serialize(path,format=fmt)
        assert isomorphic(g,Graph().parse(path,format=fmt))
    sections=''.join(f'<section id="{html.escape(r["iri"].split("/")[-1])}"><h2>{html.escape(r["label"])}</h2><p><a href="{r["iri"]}">{r["iri"]}</a></p><p>{html.escape(r["definition"])}</p></section>' for r in rows)
    page='<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Rub al-Khali ontology 3.0.1</title><style>body{font:18px/1.6 system-ui;max-width:900px;margin:3rem auto;padding:1rem;color:#172e32}section{border-top:1px solid #ccc;padding:1rem 0}a{color:#146475}h2{font-size:1.3rem}</style><main><h1>Rub al-Khali ontology 3.0.1</h1><p>342 project terms describing desert microbiome samples, measurements and provenance.</p><p>Project terms: <a href="https://creativecommons.org/licenses/by/4.0/">CC BY 4.0</a>. Imported vocabularies retain their own licences. Definitions drafted with Claude Code Sonnet and reviewed by Codex; <a href="'+BASE+'definition-provenance.json">definition provenance</a>.</p><p><a href="'+BASE+'modules/rubalkhali.owl">OWL</a> · <a href="'+BASE+'ontology/rubalkhali.ttl">Turtle</a> · <a href="https://rubalkhali.science/data">Dataset and downloads</a></p>'+sections+'</main></html>'
    (output/'ontology-3.0.1.html').write_text(page)
    report=dict(version='3.0.1',source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),source_triples=len(old),triples=len(g),project_terms=len(terms),defined_terms=len(rows),term_axioms_preserved=True,reference_imports=4,license=str(LICENSE))
    (output/'ontology-validation.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--definitions',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();build(a.source,a.definitions,a.output)
