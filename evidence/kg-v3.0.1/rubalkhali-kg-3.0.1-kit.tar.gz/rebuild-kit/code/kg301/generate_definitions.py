import json,subprocess,concurrent.futures
from pathlib import Path
import argparse
parser=argparse.ArgumentParser(description='Draft ontology definitions with actual Claude Code Sonnet; review before release.')
parser.add_argument('--context',type=Path,required=True,help='term-context.json')
parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args();r=args.output.resolve();r.mkdir(parents=True,exist_ok=True)
terms=json.loads(args.context.read_text())
batches=[terms[i:i+70] for i in range(0,len(terms),70)]
for i,batch in enumerate(batches,1):(r/f'terms-{i}.json').write_text(json.dumps(batch,ensure_ascii=False))
schema={'type':'object','properties':{'definitions':{'type':'array','items':{'type':'object','properties':{'iri':{'type':'string'},'definition':{'type':'string'},'review_note':{'type':'string'}},'required':['iri','definition','review_note'],'additionalProperties':False}}},'required':['definitions'],'additionalProperties':False}
context='''You are drafting textual definitions for the project-authored Rub al-Khali ontology, release 3.0.1. Return exactly one definition for every supplied IRI. This is a desert soil microbiome/geochemical field dataset. Use English genus-and-differentia definitions, one or two precise sentences. Properties: state subject, object/value, and relation direction. Classes: use the actual parent meaning and restrictive axioms, not merely a circular paraphrase of the label. Named device classes describe devices, not a unique physical device. Do not invent units, thresholds, provenance citations, causal effects, normalisation, or measurement procedures absent from context. XRF Light Elements are an instrument-reported aggregate with undocumented units, not a specific compound or validated percentage. Soil root-adjacent status does not establish plant growth promotion. Relative/absolute abundance meanings must respect numerical property ranges and labels. Do not change axioms. Flag ambiguity or inconsistent axioms in review_note instead of silently resolving it. A definition should make a term usable outside a single observation, while preserving project-specific protocol scope where necessary. Parent/reference labels have been resolved from pinned SIO/PATO/ENVO/UO inputs. Output definitions only in the required JSON schema. Do not include citations or claim human review.\n\nTERMS:\n'''
def run(i):
 out=r/f'sonnet-{i}.json'
 if out.exists():return
 prompt=context+(r/f'terms-{i}.json').read_text()
 p=subprocess.run(['claude','-p','--model','sonnet','--tools','','--no-session-persistence','--setting-sources','','--strict-mcp-config','--output-format','json','--json-schema',json.dumps(schema)],input=prompt,text=True,capture_output=True,cwd=r,timeout=900)
 out.write_text(p.stdout);(r/f'sonnet-{i}.stderr').write_text(p.stderr)
 print('batch',i,'exit',p.returncode,flush=True)
 if p.returncode:raise RuntimeError('Claude Code batch '+str(i)+' failed')
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(run,range(1,len(batches)+1)))
