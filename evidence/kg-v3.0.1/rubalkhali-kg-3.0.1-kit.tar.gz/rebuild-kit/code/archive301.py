from pathlib import Path
import tarfile,gzip,json,hashlib
R=Path('/mnt/data1/empty-quarter-releases/kg-3.0.1-20261004');p=R/'publication/kg/3.0.1/rubalkhali-kg-3.0.1-modules.tar.gz'
with p.open('xb') as raw,gzip.GzipFile(filename='',fileobj=raw,mode='wb',compresslevel=1,mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as t:
 for f in sorted((R/'inputs/scientific').iterdir()):
  if f.suffix in ('.ttl','.owl') or f.name=='manifest.json':t.add(f,arcname='scientific/'+f.name)
 for n in ['LICENSE-DATA.md','LICENSE-SOFTWARE','THIRD_PARTY_ATTRIBUTIONS.json']:t.add(R/'code/kg301'/n,arcname=n)
print('Module archive complete',flush=True)
