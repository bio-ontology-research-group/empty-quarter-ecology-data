import subprocess,time,urllib.request,json,sys
from pathlib import Path
R=Path('/mnt/data1/empty-quarter-releases/kg-3.0.1-20261004');py=str(R/'venv/bin/python')
def run(name,args=()):
 with (R/'evidence'/(name+'-driver.log')).open('w') as log:
  subprocess.run([py,str(R/'code'/name),*args],stdout=log,stderr=subprocess.STDOUT,check=True)
for _ in range(90):
 try:
  urllib.request.urlopen('http://127.0.0.1:18896/sparql?query=ASK%7B%3Fs%20%3Fp%20%3Fo%7D',timeout=5).close();break
 except Exception:time.sleep(2)
else:raise TimeoutError('Database startup')
run('load_asserted.py',['--root',str(R),'--container','eq_kg_3_0_1','--endpoint','http://127.0.0.1:18896/sparql'])
report=json.loads((R/'evidence/asserted_load/report.json').read_text());assert report['triples']==45707660
jobs=[]
for n in ['rebuild_export.py','validate_export.py','archive301.py']:
 log=(R/'evidence'/(n+'-driver.log')).open('w');jobs.append((n,subprocess.Popen([py,str(R/'code'/n)],stdout=log,stderr=subprocess.STDOUT),log))
for n,p,log in jobs:
 assert p.wait()==0,n;log.close()
run('validate_modules.py')
run('prepare_vm_snapshot.py')
print('All rebuild/export/package/snapshot phases passed',flush=True)
